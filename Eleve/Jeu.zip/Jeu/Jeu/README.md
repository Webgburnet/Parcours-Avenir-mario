# A 2D Game Engine For Processing/Processing.js

A Processing library for use in 2D game making,
fully compatible with online deployedment via
the Processing.js library.

- Tests are in the ./tests/ directory
- The "mario" demonstrator is in the ./mario dir (either delete or comment off testcode.pde if using the PDE)
- The main engine entry point is ./GameLoader (make sure to uncomment spriteengine.pde if you want to run the code in the PDE)

This code is unlicensed as being public domain. Do with it whatever you want.

- Mike "Pomax" Kamermans
